function[afun2]= afun2_IRS(x,y,h)
global afun2
%Ram�rez Salazar Isaura
%Martes, 2019-2
afun2= 2x*5y-h;
