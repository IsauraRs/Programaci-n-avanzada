function [bfun2]=bfun_IRS(x,y,h)
global bfun2
%Ram�rez Salazar Isaura
%Martes, 2019-2
bfun2= 10*(x+6y)*4h;