function [qfun2]=qfun2_IRS(x,y,h)
global qfun2
%Ram�rez Salazar Isaura
%Martes,2019-2
qfun2= ((2*x)+y)*10h;