function [gamfun2]=gamfun2_IRS(x,y,h)
global gamfun2
%Ram�rez Salazar Isaura
%Martes, 2019-2
gamfun2= x-y-h;